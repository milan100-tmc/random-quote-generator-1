export interface Quote {
  id: string;
  text: string;
  author: string;
  category: string;
}

export interface QuoteData {
  categories: {
    [key: string]: Quote[];
  };
}

export type Category = 'all' | 'motivational' | 'wisdom' | 'humor' | 'success' | 'life' | 'inspiration';

export interface AppState {
  currentQuote: Quote | null;
  favorites: Quote[];
  selectedCategory: Category;
  isDarkMode: boolean;
  isLoading: boolean;
  error: string | null;
}
